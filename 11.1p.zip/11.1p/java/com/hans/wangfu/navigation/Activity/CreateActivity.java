package com.hans.wangfu.navigation.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.hans.wangfu.navigation.LocationActivity;
import com.hans.wangfu.navigation.R;
import com.hans.wangfu.navigation.Utils.LogUtils;


public class CreateActivity extends AppCompatActivity implements View.OnClickListener {
    EditText etname,etphone,etdesc,etdate,etloc;
    private UserDataManager mUserDataManager;

    RadioGroup group;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        group=findViewById(R.id.rg_classfy);
        etname=findViewById(R.id.et_name);
        etphone=findViewById(R.id.et_phone);
        etdesc=findViewById(R.id.et_desc);
        etdate=findViewById(R.id.et_date);
        etloc=findViewById(R.id.et_loc);
        etloc.setOnClickListener(this);
    }

    public void onClick1(View view) {
        String selectClassfy = ((RadioButton) findViewById(group
                .getCheckedRadioButtonId())).getText().toString();
        String name=etname.getText().toString();
        String phone=etphone.getText().toString();
        String desc=etdesc.getText().toString();
        String date=etdate.getText().toString();
        String loc=etloc.getText().toString();
        if (name.isEmpty() || desc.isEmpty()|| phone.isEmpty()||date.isEmpty()||loc.isEmpty()){
            Toast.makeText(this,"input is empty",Toast.LENGTH_SHORT).show();
        }else{
            if (mUserDataManager == null) {
                mUserDataManager = new UserDataManager(this);
                mUserDataManager.openDataBase();  //建立本地数据库
            }
            UserData mUser = new UserData(Integer.valueOf(phone), name, selectClassfy+" "+desc,date, loc);
            long flag = mUserDataManager.insertUserData(mUser);
            if (flag == -1) {
                Toast.makeText(getApplicationContext(),"save failed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "save successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }


    @Override
    public void onClick(View view) {
        if (view==etloc){
            Intent intent=new Intent(this,LocationActivity.class);
            startActivityForResult(intent,0);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(LogUtils.filename(new Exception()),LogUtils.funAndLine(new Exception())+
                requestCode+"|"+resultCode);
        if (requestCode==0 && resultCode==0){
            String loc = data.getStringExtra("loc"); //获取回传的数据
            etloc.setText(loc);
        }

    }
}