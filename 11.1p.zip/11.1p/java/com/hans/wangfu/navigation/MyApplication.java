package com.hans.wangfu.navigation;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import com.hans.wangfu.navigation.Utils.SPUtils;


public class MyApplication extends Application {

    public static MyApplication application;
    private static Context context;

    /**
     * 获取上下文
     * @return
     */
    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        application = this;
        context = getApplicationContext();
        SPUtils.init(this);
        //第一：默认初始化
        createNotificationChannel();
    }

    /*
  在 Android 8.0 及更高版本上提供通知，需要在系统中注册应用的通知渠道。
   */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name ="您有待确认派送的快递";
            String description = "您有快递来了，请确认是否需要快递员今日配送";
            //不同的重要程度会影响通知显示的方式
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
        }
    }
}
