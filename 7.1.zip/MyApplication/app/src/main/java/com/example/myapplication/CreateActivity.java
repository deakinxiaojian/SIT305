package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateActivity extends AppCompatActivity {
    EditText etname,etphone,etdesc,etdate,etloc;
    private UserDataManager mUserDataManager;

    RadioGroup group;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        group=findViewById(R.id.rg_classfy);
        etname=findViewById(R.id.et_name);
        etphone=findViewById(R.id.et_phone);
        etdesc=findViewById(R.id.et_desc);
        etdate=findViewById(R.id.et_date);
        etloc=findViewById(R.id.et_loc);
    }

    public void onClick1(View view) {
        String selectClassfy = ((RadioButton) findViewById(group
                .getCheckedRadioButtonId())).getText().toString();
        String name=etname.getText().toString();
        String phone=etphone.getText().toString();
        String desc=etdesc.getText().toString();
        String date=etdate.getText().toString();
        String loc=etloc.getText().toString();
        if (name.isEmpty() || desc.isEmpty()|| phone.isEmpty()||date.isEmpty()||loc.isEmpty()){
            Toast.makeText(this,"input is empty",Toast.LENGTH_SHORT).show();
        }else{
            if (mUserDataManager == null) {
                mUserDataManager = new UserDataManager(this);
                mUserDataManager.openDataBase();  //建立本地数据库
            }
            UserData mUser = new UserData(Integer.valueOf(phone), name, selectClassfy+" "+desc,date, loc);
            long flag = mUserDataManager.insertUserData(mUser);
            if (flag == -1) {
                Toast.makeText(getApplicationContext(),"save failed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "save successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }


}