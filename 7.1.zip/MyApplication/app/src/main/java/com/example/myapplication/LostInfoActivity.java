package com.example.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LostInfoActivity extends AppCompatActivity {
    TextView etdate,etdesc,etloc;
    private UserDataManager mUserDataManager;
    private int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lostinfo);
        etdesc=findViewById(R.id.desc);
        etdate=findViewById(R.id.date);

        etloc=findViewById(R.id.loc);

        id=Integer.valueOf(getIntent().getStringExtra("userid"));
        etdesc.setText(getIntent().getStringExtra("usersex"));
        etdate.setText(getIntent().getStringExtra("userclass"));
        etloc.setText(getIntent().getStringExtra("userscore"));
    }

    public void onClick1(View view) {
        new AlertDialog.Builder(this).setIcon(R.mipmap.ic_launcher).setTitle("delete")
                .setMessage("do you want remove it?").setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //ToDo: 你想做的事情
                if (mUserDataManager == null) {
                    mUserDataManager = new UserDataManager(LostInfoActivity.this);
                    mUserDataManager.openDataBase();                              //建立本地数据库
                }
                mUserDataManager.deleteUserData(id);
                Toast.makeText(getApplicationContext(), "remove successfully", Toast.LENGTH_SHORT).show();
                Intent intent = getIntent();
                setResult(0, intent);
                finish();

            }
        }).setNegativeButton("no", null).show();
    }
}