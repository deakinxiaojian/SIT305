package com.hans.wangfu.navigation.Activity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


import com.hans.wangfu.navigation.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowListActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    private ListView listView;
    private UserDataManager mUserDataManager;         //用户数据管理类
    private List<UserData> userDataList = new ArrayList<>();
    private HashMap<String, Object> mHashMap;
    private SimpleAdapter mSimpleAdapter;
    private SearchView searchView ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);

        listView = (ListView) findViewById(R.id.list);
        listView.setOnItemClickListener(this);


             /*
        SearchView
        1 注册监听器：当内容改变就做出响应
        2 响应内容：根据输入文本，动态调用homeFragment的初始化方法init(String),init()
         */
        searchView = (SearchView)findViewById(R.id.searchview) ;
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            //搜索框内部改变回调，newText就是搜索框里的内容
            @Override
            public boolean onQueryTextChange(String newText) {

                /*
                为空的时候调用默认的初始化方法
                 */
                if (newText.equals(""))
                {

                }

                /*
                不为空的时候调用默认的查询列表显示方法
                 */
                else {
                    initData(newText);

                }

                return true;
            }
        });

        initData(null);
    }

    //初始化
    @SuppressLint("Range")
    private void initData(String str) {

        if (mUserDataManager == null) {
            mUserDataManager = new UserDataManager(this);
            mUserDataManager.openDataBase();                              //建立本地数据库
        }
        userDataList.clear();
        mUserDataManager.openDataBase();
        Cursor cursor=mUserDataManager.fetchAllUserDatas();
        List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
        try {
            while (cursor.moveToNext()) {
                mHashMap = new HashMap<>();
                mHashMap.put(UserDataManager.ID, cursor.getInt(cursor.getColumnIndex(UserDataManager.ID))+"");
                mHashMap.put(UserDataManager.USER_PHONE, cursor.getInt(cursor.getColumnIndex(UserDataManager.USER_PHONE))+"");
                mHashMap.put(UserDataManager.USER_NAME, cursor.getString(cursor.getColumnIndex(UserDataManager.USER_NAME)));
                mHashMap.put(UserDataManager.USER_SEX, cursor.getString(cursor.getColumnIndex(UserDataManager.USER_SEX)));
                mHashMap.put(UserDataManager.USER_CLASS, cursor.getString(cursor.getColumnIndex(UserDataManager.USER_CLASS)));
                mHashMap.put(UserDataManager.USER_HEIGHT, cursor.getString(cursor.getColumnIndex(UserDataManager.USER_HEIGHT)));
                if (str!=null) {
                    if (str.equals(cursor.getString(cursor.getColumnIndex(UserDataManager.USER_NAME))))
                        mapList.add(mHashMap);
                } else{
                    mapList.add(mHashMap);
                }
            }
            mSimpleAdapter = new SimpleAdapter(getBaseContext(), mapList, R.layout.user_list_item,
                    new String[]{UserDataManager.ID,
                            UserDataManager.USER_PHONE,
                            UserDataManager.USER_NAME,
                           UserDataManager.USER_SEX,
                           UserDataManager.USER_CLASS,
                           UserDataManager.USER_HEIGHT},
                    new int[]{ R.id.tv_stu_id, R.id.tv_stu_userid, R.id.tv_stu_name, R.id.tv_stu_pwd,R.id.tv_stu_sex,
                            R.id.tv_stu_likes});
            listView.setAdapter(mSimpleAdapter);
            mSimpleAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("ShowUserInfoActivity","error:"+e.getMessage());
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

         TextView tvId=view.findViewById(R.id.tv_stu_id);
         String userid=tvId.getText().toString();
        TextView tvnum=view.findViewById(R.id.tv_stu_userid);
        String usernum=tvnum.getText().toString();
        TextView tvname=view.findViewById(R.id.tv_stu_name);
        String username=tvname.getText().toString();
        TextView tvsex=view.findViewById(R.id.tv_stu_pwd);
        String usersex=tvsex.getText().toString();
        TextView tvclass=view.findViewById(R.id.tv_stu_sex);
        String userclass=tvclass.getText().toString();
        TextView tvscore=view.findViewById(R.id.tv_stu_likes);
        String userscore=tvscore.getText().toString();

        Intent intent=new Intent(this, LostInfoActivity.class);
        intent.putExtra("userid",userid);
        intent.putExtra("usernum",usernum);
        intent.putExtra("username",username);
        intent.putExtra("usersex",usersex);
        intent.putExtra("userclass",userclass);
        intent.putExtra("userscore",userscore);
        startActivityForResult(intent,0);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        initData(null);
    }

}
