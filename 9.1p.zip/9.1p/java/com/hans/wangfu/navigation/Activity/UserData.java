package com.hans.wangfu.navigation.Activity;

public class UserData {
    private String userName;                  //用户名
    private String usersex;                   //用户密码
    private String userclass;                //用户性别
    private String userheight;
    private int userId;                       //用户ID号
    public int pwdresetFlag=0;
    //获取用户名
    public String getUserName() {             //获取用户名
        return userName;
    }
    //设置用户名
    public void setUserName(String userName) {  //输入用户名
        this.userName = userName;
    }
    //获取用户性别
    public String getUserclass() {
        return userclass;
    }
    //设置用户性别
    public void setUserclass(String userclass) {     //输入用户密码
        this.userclass = userclass;
    }

    //设置用户爱好
    public void setUserheight(String userheight) {     //输入用户密码
        this.userheight = userheight;
    }

    //获取用户爱好
    public String getUserheight() {                //获取用户密码
        return userheight;
    }

    //获取用户密码
    public String getUsersex() {                //获取用户密码
        return usersex;
    }
    //设置用户密码
    public void setUsersex(String usersex) {     //输入用户密码
        this.usersex = usersex;
    }

    //获取用户id
    public int getUserId() {                   //获取用户ID号
        return userId;
    }
    //设置用户id
    public void setUserId(int userId) {       //设置用户ID号
        this.userId = userId;
    }
    public UserData() {  //这里只采用用户名和密码
        super();
    }
    public UserData(String userName, String usersex) {  //这里只采用用户名和密码
        super();
        this.userName = userName;
        this.usersex = usersex;
    }
    public UserData(String userName, String usersex, String userclass) {  //这里采用用户名和密码,性别，爱好
        super();
        this.userName = userName;
        this.usersex = usersex;
        this.userclass = userclass;
    }
    public UserData(int userId, String userName, String usersex, String userclass, String userheight) {  //这里采用用户名和密码,性别，爱好
        super();
        this.userId=userId;
        this.userName = userName;
        this.usersex = usersex;
        this.userclass = userclass;
        this.userheight=userheight;
    }
 
}