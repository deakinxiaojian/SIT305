package com.hans.wangfu.navigation;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdate;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.LocationSource;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.CameraPosition;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.animation.Animation;
import com.amap.api.maps.model.animation.ScaleAnimation;
import com.amap.api.services.core.AMapException;
import com.amap.api.services.core.LatLonPoint;
import com.amap.api.services.core.PoiItem;
import com.amap.api.services.core.SuggestionCity;
import com.amap.api.services.geocoder.GeocodeResult;
import com.amap.api.services.geocoder.GeocodeSearch;
import com.amap.api.services.geocoder.RegeocodeAddress;
import com.amap.api.services.geocoder.RegeocodeQuery;
import com.amap.api.services.geocoder.RegeocodeResult;
import com.amap.api.services.help.Inputtips;
import com.amap.api.services.help.InputtipsQuery;
import com.amap.api.services.help.Tip;
import com.amap.api.services.poisearch.PoiResult;
import com.amap.api.services.poisearch.PoiSearch;
import com.baidu.speech.EventListener;
import com.baidu.speech.EventManager;
import com.baidu.speech.EventManagerFactory;
import com.baidu.speech.asr.SpeechConstant;
import com.hans.wangfu.navigation.Activity.UserDataManager;
import com.hans.wangfu.navigation.Utils.SPUtils;
import com.hans.wangfu.navigation.db.ShopLoc;
import com.mancj.materialsearchbar.MaterialSearchBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LocationActivity extends AppCompatActivity implements LocationSource, AMapLocationListener, AMap.OnCameraChangeListener,
        MaterialSearchBar.OnSearchActionListener, PoiSearch.OnPoiSearchListener, AMap.OnMapClickListener,
        Animation.AnimationListener, GeocodeSearch.OnGeocodeSearchListener, SpeechRecognizerTool.ResultsCallback, EventListener, AMap.OnMarkerClickListener {
    @BindView(R.id.toolbar)
    android.support.v7.widget.Toolbar toolbar;
    @BindView(R.id.map)
    MapView mMapView;
    @BindView(R.id.searchBar)
    MaterialSearchBar searchBar;
    @BindView(R.id.list)
    ListView list;
    private  Tip selectPoi;
    private Adapter adapter;
    private Context mContext = this;
    private double mLongitude;
    private double mLatitude;
    private String cityCode;
    private PoiResult poiResult; // poi返回的结果
    private int currentPage = 0;// 当前页面，从0开始计数
    private PoiSearch.Query query;// Poi查询条件类
    private LatLonPoint latLonPoint;
    private PoiSearch poiSearch;
    private List<PoiItem> poiItems;// poi数据
    private String keyWord;
    private String POI_SEARCH_TYPE = "汽车服务|汽车销售|" +
            "//汽车维修|摩托车服务|餐饮服务|购物服务|生活服务|体育休闲服务|医疗保健服务|" +
            "//住宿服务|风景名胜|商务住宅|政府机构及社会团体|科教文化服务|交通设施服务|" +
            "//金融保险服务|公司企业|道路附属设施|地名地址信息|公共设施";
    private AMap aMap;
    private String currentCity="合肥";
    //声明AMapLocationClient类对象，定位发起端
    private AMapLocationClient mLocationClient = null;
    //声明mLocationOption对象，定位参数
    public AMapLocationClientOption mLocationOption = null;
    //声明mListener对象，定位监听器
    private OnLocationChangedListener mListener = null;
    //标识，用于判断是否只显示一次定位信息和用户重新定位
    private boolean isFirstLoc = true;
    private Button btnNavi;
    private Button btncurrentloc;
    private Button btnqrcode;
    private  String currentloc;
    private  String selectLoc;
    private  double selectLat;
    private  double selectLon;
    GeocodeSearch geocodeSearch;
    private Button mStartSpeechButton;
    private SpeechRecognizerTool mSpeechRecognizerTool;
    private UserDataManager mUserDataManager;         //用户数据管理类
    private EventManager asr;
    private List<ShopLoc> shopLocs;
    private String[] descs={"very good","Very delicious","high quality and inexpensive",
            "In promotional activities","Affordable price"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        ButterKnife.bind(this);
        //在activity执行onCreate时执行mMapView.onCreate(savedInstanceState)，创建地图
        mMapView.onCreate(savedInstanceState);

       // setSupportActionBar(toolbar);
        //初始化地图控制器对象
        if (aMap == null) {
            aMap = mMapView.getMap();
            UiSettings settings = aMap.getUiSettings();
            aMap.setLocationSource(this);//设置了定位的监听
            // 是否显示定位按钮
            settings.setMyLocationButtonEnabled(true);
            aMap.setMyLocationEnabled(true);//显示定位层并且可以触发定位,默认是flase
            aMap.setMapLanguage(AMap.ENGLISH);
            aMap.setOnMapClickListener(this);
            aMap.setOnMarkerClickListener(this);
        }
        mSpeechRecognizerTool=new SpeechRecognizerTool(LocationActivity.this);
        //地理搜索类
        geocodeSearch = new GeocodeSearch(this);
        geocodeSearch.setOnGeocodeSearchListener(this);
        location();
        initView();

        /**
         * 动态获取权限，Android 6.0 新特性，一些保护权限，除了要在AndroidManifest中声明权限，还要使用如下代码动态获取
         */
        if (Build.VERSION.SDK_INT >= 23) {
            int REQUEST_CODE_CONTACT = 101;
            String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS,
                    Manifest.permission.INTERNET,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.WAKE_LOCK,
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_LOGS,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,

            };
            //验证是否许可权限
            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    //申请权限
                    this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                    return;
                }
            }
        }
        asr = EventManagerFactory.create(this,"asr");//注册自己的输出事件类
        asr.registerListener(this);//// 调用 EventListener 中 onEvent方法

        mStartSpeechButton = (Button) findViewById(R.id.startSpeechButton);
       /* mStartSpeechButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        mSpeechRecognizerTool.startASR(LocationActivity.this);
                       *//* mStartSpeechButton.setBackgroundResource(
                                R.drawable.bdspeech_btn_orangelight_pressed);*//*
                        break;
                    case MotionEvent.ACTION_UP:
                        mSpeechRecognizerTool.stopASR();
                       *//* mStartSpeechButton.setBackgroundResource(
                                R.drawable.bdspeech_btn_orangelight_normal);*//*
                        break;
                    default:
                        return false;
                }
                return true;
            }
        });*/

        mStartSpeechButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        start();
                        /*mStartSpeechButton.setBackgroundResource(
                                R.drawable.bdspeech_btn_orangelight_pressed);*/
                        break;
                    case MotionEvent.ACTION_UP:
                        stop();
                        /*mStartSpeechButton.setBackgroundResource(
                                R.drawable.bdspeech_btn_orangelight_normal);*/
                        break;
                    default:
                        return false;
                }

                return true;
            }
        });

    }
    private void start(){
        Toast.makeText(mContext, "请开始说话", Toast.LENGTH_SHORT).show();

        Map<String,Object> params = new LinkedHashMap<>();//传递Map<String,Object>的参数，会将Map自动序列化为json
        String event = null;
        event = SpeechConstant.ASR_START;
        params.put(SpeechConstant.ACCEPT_AUDIO_VOLUME,false);//回调当前音量
        String json = null;
        json = new JSONObject(params).toString();//demo用json数据来做数据交换的方式
        asr.send(event, json, null, 0, 0);// 初始化EventManager对象,这个实例只能创建一次，就是我们上方创建的asr，此处开始传入
    }
    private void stop(){
        searchBar.setText("停止识别：ASR_STOP");
        asr.send(SpeechConstant.ASR_STOP, null, null, 0, 0);//此处停止
    }

    private Handler mHandler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 2:
                for (ShopLoc shopLoc:shopLocs) {
                    Double lat = Double.valueOf(shopLoc.getLat());
                    Double lon = Double.valueOf(shopLoc.getLon());
                    CameraPosition cameraPosition = new CameraPosition(new LatLng(lat, lon), 15, 0, 30);
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newCameraPosition(cameraPosition);
                    aMap.moveCamera(cameraUpdate);
                    //添加标注
                    addMarkers(shopLoc);
                }
                   /* doSearchQuery();
                    aMap.addMarker(getMarkerOption("", lat,lon, R.drawable.ic_express));
                    //设置缩放级别
                    aMap.moveCamera(CameraUpdateFactory.zoomTo(17));
                    aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 20))*/;

                    break;
                default:
                    break;
            }
        }

    };
    /**
     * 添加标注
     */
    private void addMarkers(ShopLoc myOrder) {
        Double lat=Double.valueOf(myOrder.getLat());
        Double lon=Double.valueOf(myOrder.getLon());
        MarkerOptions markerOptions = new MarkerOptions();

        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_mark));

        markerOptions.position(new LatLng(lat,lon));
        markerOptions.title(myOrder.getShopName());
        //markerOptions.snippet("Desc:" + myOrder.getDesc());
        markerOptions.period(100);
/*

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.anchor(1.3f, 1.5f);//点标记的锚点
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.express);
        markerOptions.icon(BitmapDescriptorFactory
                .fromBitmap(bitmap));
        markerOptions.position(new LatLng(latitude, longitude));
*/

        Marker growMarker = aMap.addMarker(markerOptions);
        growMarker.setClickable(true); //marker 设置是否可点击

        startGrowAnimation(growMarker);
        growMarker.showInfoWindow();
    }

    private void startGrowAnimation(Marker marker) {

        if (marker != null) {
            Animation animation = new ScaleAnimation(0, 1, 0, 1);
            animation.setInterpolator(new LinearInterpolator());
            //整个移动所需要的时间
            animation.setDuration(1000);
           // animation.setFillMode(1);//动画保存之前的状态为1 之后为0
            //设置动画
            marker.setAnimation(animation);
            //开始动画
            marker.startAnimation();
            marker.showInfoWindow();
        }
    }

    private void initView() {
        toolbar.setTitle("MyLocation");


        searchBar.setOnSearchActionListener(this);
        searchBar.setCardViewElevation(10);
        searchBar.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                list.setVisibility(View.VISIBLE);
                InputtipsQuery inputquery = new InputtipsQuery(String.valueOf(charSequence), currentCity);
                inputquery.setCityLimit(true);
                Inputtips inputTips = new Inputtips(mContext, inputquery);
                inputTips.setInputtipsListener(new Inputtips.InputtipsListener() {
                    @Override
                    public void onGetInputtips(final List<Tip> tips, int i) {
                        //1000为成功
                        if (i == 1000) {
                            adapter = new Adapter(mContext, tips, R.layout.item_list);
                            list.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
                inputTips.requestInputtipsAsyn();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectPoi =  ((Tip) parent.getItemAtPosition(position));
                searchBar.setText(selectPoi.getName());
                doSearchQuery();
                aMap.addMarker(getMarkerOption(selectPoi.getName(),selectPoi.getPoint().getLatitude(),selectPoi.getPoint().getLongitude(),R.drawable.location));
                //设置缩放级别
                aMap.moveCamera(CameraUpdateFactory.zoomTo(17));
                aMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(selectPoi.getPoint().getLatitude(), selectPoi.getPoint().getLongitude()), 20));
                list.setVisibility(View.INVISIBLE);

            }
        });
    }

    /**
     * 自定义图标
     * @return
     */
    public MarkerOptions getMarkerOption(String str, double lat, double lgt, int a){
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.icon(BitmapDescriptorFactory.fromResource(a));
        markerOptions.position(new LatLng(lat,lgt));
        markerOptions.title(str);
        markerOptions.snippet("纬度:" + lat + "   经度:" + lgt);
        markerOptions.period(100);
        return markerOptions;
    }
    private void location() {
        //初始化定位
        mLocationClient = new AMapLocationClient(getApplicationContext());
        //设置定位回调监听
        mLocationClient.setLocationListener(this);
        //初始化定位参数
        mLocationOption = new AMapLocationClientOption();
        //设置定位模式为Hight_Accuracy高精度模式，Battery_Saving为低功耗模式，Device_Sensors是仅设备模式
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        //设置是否强制刷新WIFI，默认为强制刷新
        mLocationOption.setWifiActiveScan(true);
        //设置定位间隔 默认采用连续定位模式，时间间隔为2000ms 可以自定义
        mLocationOption.setInterval(2000);
        //设置是否返回地址信息，默认返回
        mLocationOption.setNeedAddress(true);
        //设置是否允许模拟软件Mock位置结果，多为模拟GPS定位结果，默认为true，允许模拟位置
        mLocationOption.setMockEnable(true);
        //设置定位请求超时时间，默认为30秒
        mLocationOption.setHttpTimeOut(20000);
        //设置是否开启定位缓存机制 默认开启
        mLocationOption.setLocationCacheEnable(false);

        //给定位客户端对象设置定位参数
        mLocationClient.setLocationOption(mLocationOption);
        //启动定位
        mLocationClient.startLocation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，销毁地图
        mMapView.onDestroy();
        mLocationClient.stopLocation();//停止定位
        mLocationClient.onDestroy();//销毁定位客户端。
        searchBar.destroyDrawingCache();
        if (asr!=null) {
            asr.send(SpeechConstant.ASR_CANCEL, "{}", null, 0, 0);
            asr.unregisterListener(this);//退出事件管理器
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView.onResume ()，重新绘制加载地图
        mMapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView.onPause ()，暂停地图的绘制
        mMapView.onPause();
       // asr.send(SpeechConstant.ASR_CANCEL, "{}", null, 0, 0);

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //在activity执行onSaveInstanceState时执行mMapView.onSaveInstanceState (outState)，保存地图当前的状态
        mMapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLocationChanged(AMapLocation aMapLocation) {
        if (aMapLocation != null) {
            if (aMapLocation.getErrorCode() == 0) {
                //定位成功回调信息，设置相关消息
                aMapLocation.getLocationType();//获取当前定位结果来源，如网络定位结果，详见官方定位类型表
                aMapLocation.getLatitude();//获取纬度
                aMapLocation.getLongitude();//获取经度
                mLatitude=aMapLocation.getLatitude();//获取纬度
                mLongitude=aMapLocation.getLongitude();//获取经度
                aMapLocation.getAccuracy();//获取精度信息
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = new Date(aMapLocation.getTime());
                df.format(date);//定位时间
                aMapLocation.getAddress();//地址，如果option中设置isNeedAddress为false，则没有此结果，网络定位结果中会有地址信息，GPS定位不返回地址信息。
                aMapLocation.getCountry();//国家信息
                aMapLocation.getProvince();//省信息
                aMapLocation.getCity();//城市信息
                aMapLocation.getDistrict();//城区信息
                aMapLocation.getStreet();//街道信息
                aMapLocation.getStreetNum();//街道门牌号信息
                aMapLocation.getCityCode();//城市编码
                aMapLocation.getAdCode();//地区编码
               
                currentCity = aMapLocation.getCity();
                // 如果不设置标志位，此时再拖动地图时，它会不断将地图移动到当前的位置
                //获取定位信息
                StringBuffer buffer = new StringBuffer();
                buffer.append(aMapLocation.getCountry() + ""
                        + aMapLocation.getProvince() + ""
                        + aMapLocation.getCity() + ""
                        + aMapLocation.getProvince() + ""
                        + aMapLocation.getDistrict() + ""
                        + aMapLocation.getStreet() + ""
                        + aMapLocation.getStreetNum());
                currentloc = buffer.toString();

                if (isFirstLoc) {
                    //设置缩放级别
                    aMap.moveCamera(CameraUpdateFactory.zoomTo(17));
                    //将地图移动到定位点
                    aMap.moveCamera(CameraUpdateFactory.changeLatLng(new LatLng(aMapLocation.getLatitude(), aMapLocation.getLongitude())));
                    //点击定位按钮 能够将地图的中心移动到定位点
                    mListener.onLocationChanged(aMapLocation);
                    isFirstLoc = false;
                    if (getIntent().getIntExtra("all",0)!=0)
                        generateShop();
                }
            } else {
                //显示错误信息ErrCode是错误码，errInfo是错误信息，详见错误码表。
                Log.e("AmapError", "location Error, ErrCode:"
                        + aMapLocation.getErrorCode() + ", errInfo:"
                        + aMapLocation.getErrorInfo());
               //Toast.makeText(getApplicationContext(), "定位失败", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void generateShop() {
        shopLocs=new ArrayList<>();

            if (mUserDataManager == null) {
                mUserDataManager = new UserDataManager(this);
                mUserDataManager.openDataBase();                              //建立本地数据库
            }
            mUserDataManager.openDataBase();
            Cursor cursor=mUserDataManager.fetchAllUserDatas();
            List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
            try {
                while (cursor.moveToNext()) {
                    String title= cursor.getString(cursor.getColumnIndex(UserDataManager.USER_HEIGHT));
                    String strlat=SPUtils.getString(title+"_lat");
                    String strlon=SPUtils.getString(title+"_lon");
                    if (strlat!=null && strlon!=null){
                        double lat=Double.valueOf(strlat);
                        double lon =Double.valueOf(strlon);
                        String name=title;
                        ShopLoc shopLoc=new ShopLoc(0+"",name,lat+"",lon+"",null);
                        shopLocs.add(shopLoc);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("ShowUserInfoActivity","error:"+e.getMessage());
            }
        mHandler.sendEmptyMessageDelayed(2, 3000);

    }


    @Override
    public void activate(OnLocationChangedListener onLocationChangedListener) {
        mListener = onLocationChangedListener;
    }

    @Override
    public void deactivate() {
        mListener = null;
    }

    @Override
    public void onSearchStateChanged(boolean enabled) {

    }

    @Override
    public void onSearchConfirmed(CharSequence text) {

    }

    @Override
    public void onButtonClicked(int buttonCode) {
        switch (buttonCode) {
            case MaterialSearchBar.BUTTON_BACK:
                searchBar.disableSearch();
                list.removeAllViews();
                break;
        }
    }
    /**
     * 开始进行poi搜索
     */
    protected void doSearchQuery(){
        latLonPoint = new LatLonPoint(mLatitude,mLongitude);// 116.472995,39.993743

        keyWord = searchBar.getText().toString().trim();
        currentPage = 0;
        //keyWord表示搜索字符串，
        //第二个参数表示POI搜索类型，二者选填其一，选用POI搜索类型时建议填写类型代码，码表可以参考下方（而非文字）
        //cityCode表示POI搜索区域，可以是城市编码也可以是城市名称，也可以传空字符串，空字符串代表全国在全国范围内进行搜索
        query = new PoiSearch.Query(keyWord, POI_SEARCH_TYPE, currentCity);
        query.setPageSize(30);// 设置每页最多返回多少条poiItem
        query.setPageNum(currentPage);// 设置查第一页
        if (latLonPoint != null) {
            poiSearch = new PoiSearch(this, query);
            poiSearch.setOnPoiSearchListener(this);
            poiSearch.setBound(new PoiSearch.SearchBound(latLonPoint, 3000, true));//设置搜索范围
            poiSearch.searchPOIAsyn();// 异步搜索
        }

    }

    // 拖动地图
    @Override
    public void onCameraChange(CameraPosition cameraPosition) {
        //L.d("拖动地图 onCameraChange ");
    }
    /**
     * 拖动地图 结束回调
     *
     * @param cameraPosition 当地图位置发生变化，就重新查询数据（手动拖动或者代码改变地图位置都会调用）
     */
    @Override
    public void onCameraChangeFinish(CameraPosition cameraPosition) {

    }
    @Override
    public void onPoiSearched(PoiResult result, int code) {
        if (code == AMapException.CODE_AMAP_SUCCESS) {
            if (result != null && result.getQuery() != null) {// 搜索poi的结果
                Log.d("LocationActivity","搜索的code为===="+code+", result数量=="+result.getPois().size());
                if (result.getQuery().equals(query)) {// 是否是同一次搜索
                    poiResult = result;
                    Log.d("LocationActivity","搜索的code为===="+code+", result数量=="+poiResult.getPois().size());
                    List<SuggestionCity> suggestionCities = poiResult.getSearchSuggestionCitys();// 当搜索不到poiitem数据时，会返回含有搜索关键字的城市信息
                    if (poiItems != null && poiItems.size() > 0) {
                        poiItems.clear();
                       /* if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }*/
                    }
                    poiItems = poiResult.getPois();// 取得第一页的poiitem数据，页数从数字0开始

                    //通过listview显示搜索结果的操作省略

                }
            } else {
                Log.e("LocationActivity","没有搜索结果");
                Toast.makeText(mContext, "没有搜索结果", Toast.LENGTH_SHORT).show();
                //  empty_view.setText(getString(R.string.search_no_result));
            }
        } else {
            Log.e("LocationActivity","搜索出现错误");
            Toast.makeText(mContext, "搜索出现错误", Toast.LENGTH_SHORT).show();
            // empty_view.setText(getString(R.string.search_error));
        }
    }

    @Override
    public void onPoiItemSearched(PoiItem poiItem, int i) {

    }


    @Override
    public void onMapClick(LatLng latLng) {
        selectLat=latLng.latitude;
        selectLon=latLng.longitude;
        getAddressByLatlng(latLng);
    }
    private void getAddressByLatlng(LatLng latLng) {
        //逆地理编码查询条件：逆地理编码查询的地理坐标点、查询范围、坐标类型。
        LatLonPoint latLonPoint = new LatLonPoint(latLng.latitude, latLng.longitude);
        RegeocodeQuery query = new RegeocodeQuery(latLonPoint, 500f, GeocodeSearch.AMAP);
        //异步查询
        geocodeSearch.getFromLocationAsyn(query);
    }

    /**
     *  得到逆地理编码异步查询结果
     */

    @Override
    public void onRegeocodeSearched(RegeocodeResult regeocodeResult, int i) {
        RegeocodeAddress regeocodeAddress = regeocodeResult.getRegeocodeAddress();
        String formatAddress = regeocodeAddress.getFormatAddress();
        selectLoc = formatAddress.substring(9);
        searchBar.setText(selectLoc);
    }

    @Override
    public void onAnimationStart() {

    }

    @Override
    public void onAnimationEnd() {

    }


    @Override
    public void onGeocodeSearched(GeocodeResult geocodeResult, int i) {

    }

    @Override
    public void onResults(String result) {
        final String finalResult = result;
        Log.d("LocationActivity","语音识别结果为=="+result);

        LocationActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                searchBar.setText(finalResult);
            }
        });
    }

    @Override
    public void onEvent(String name, String params, byte[] data, int offset, int length) {
        String resultTxt = null;
        Log.d("LocationActivity","语音识别结果为=="+params);

        if (name.equals(SpeechConstant.CALLBACK_EVENT_ASR_PARTIAL)){//识别结果参数
            if (params.contains("\"final_result\"")){//语义结果值
                try {
                    JSONObject json = new JSONObject(params);
                    String result = json.getString("best_result");//取得key的识别结果
                    resultTxt = result;
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        if (resultTxt != null){
            resultTxt += "\n";
            searchBar.setText(resultTxt);
        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        String title=marker.getTitle();
        Intent intent = new Intent();
        intent.putExtra("loc",title);
        SPUtils.putString(title+"_lat",marker.getPosition().latitude+"");
        SPUtils.putString(title+"_lon",marker.getPosition().longitude+"");
        setResult(0, intent);
        finish();
       /* new AlertDialog.Builder(mContext).setTitle("do you want to order something？")
                .setMessage(title)
                .setNegativeButton("Back",  null)
                .setPositiveButton("Go", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent();
                        intent.putExtra("loc",title);
                        SPUtils.putString(title+"_lat",marker.getPosition().latitude+"");
                        SPUtils.putString(title+"_lat",marker.getPosition().longitude+"");
                        setResult(0, intent);
                        finish();
                      //startActivity(intent);
                    }
                })
                .show();*/
        return true;
    }

    private class Adapter extends CommonAdapter<Tip> {
        public Adapter(Context context, List<Tip> datas, int layoutId) {
            super(context, datas, layoutId);
        }

        @Override
        public void convert(CommonViewHolder holder, Tip datas) {
            holder.setText(R.id.text, datas.getName());
        }
    }
}
