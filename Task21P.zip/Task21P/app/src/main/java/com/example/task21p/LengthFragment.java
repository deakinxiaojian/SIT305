package com.example.task21p;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.math.BigDecimal;
import java.text.DecimalFormat;

/**
 * Created by zxy on 2022/3/14
 * Describe:
 */
@SuppressLint("ValidFragment")
public class LengthFragment extends Fragment {
    Context mContext;
    String mInput;
    RelativeLayout rl_length;
    TextView tv_centimetre;
    TextView tv_foot;
    TextView tv_inch;

    @SuppressLint("ValidFragment")
    public LengthFragment(Context context, String input){
        this.mContext = context;
        this.mInput = input;
    }
    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @deprecated
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frame_length, container, false);
        rl_length = view.findViewById(R.id.rl_length);
        tv_centimetre = view.findViewById(R.id.tv_centimetre);
        tv_foot = view.findViewById(R.id.tv_foot);
        tv_inch = view.findViewById(R.id.tv_inch);
        if(mInput != null && !mInput.equals("")){
            rl_length.setVisibility(View.VISIBLE);
            int m = Integer.parseInt(mInput);
            DecimalFormat df = new DecimalFormat("#,###,##0.00");
            int centimetre = m*100;
            tv_centimetre.setText(Integer.toString(centimetre));
            tv_foot.setText(df.format(m*3.281));
            tv_inch.setText(df.format(m*39.370079));
        }
        return view;
    }
}
