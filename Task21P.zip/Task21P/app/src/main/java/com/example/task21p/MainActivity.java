package com.example.task21p;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private ListPopupWindow listPopupWindow = null;
    private TextView options_text;
    private RelativeLayout rl_options;
    private ListAdapter listAdapter;
    private EditText et_input;
    private int tag_pos = 0; //0:Metre, 1:Celsius, 2:Kilograms
    private ImageView im_metre, im_celsius, im_kilograms;
    private Fragment currentFragment = new Fragment();
    private Fragment lengthFragment;
    private Fragment tempFragment;
    private Fragment weightFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rl_options = findViewById(R.id.rl_options);
        options_text = findViewById(R.id.options_text);
        et_input = findViewById(R.id.et_input);
        im_metre = findViewById(R.id.im_metre);
        im_celsius = findViewById(R.id.im_celsius);
        im_kilograms = findViewById(R.id.im_kilograms);

        rl_options.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                showListPopupWindow(rl_options);
            }
        });
        im_metre.setOnClickListener(this);
        im_celsius.setOnClickListener(this);
        im_kilograms.setOnClickListener(this);
    }


    /**
     * show the options:
     * "Metre", "celsius", "kilograms"
     * */
    public void showListPopupWindow(View view){
        if(listPopupWindow == null){
            listPopupWindow = new ListPopupWindow(this);
        }
        if(listAdapter == null) {
            listAdapter = new ListAdapter(this, android.R.layout.simple_list_item_1);
            listPopupWindow.setAdapter(listAdapter);
            listPopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
                    options_text.setText(listAdapter.getItem(pos));
                    tag_pos = pos;
                    Log.e("zxy","the pos is::" + pos);
                    listPopupWindow.dismiss();
                }
            });
        }
        listPopupWindow.setAnchorView(view);
        listPopupWindow.setVerticalOffset(dip2px(this, 5));
        listPopupWindow.setWidth(view.getWidth());
        listPopupWindow.setModal(true);
        listPopupWindow.show();
    }

    public static int dip2px(Context context, float dipValue) {
        float sDensity = context.getResources().getDisplayMetrics().density;
        final float scale = sDensity;
        return (int) (dipValue * scale + 0.5f);
    }

    private class ListAdapter extends ArrayAdapter{

        private String[] strs = {"Metre", "celsius", "kilograms"};
        private LayoutInflater inflater;
        private int res;

        public ListAdapter(@NonNull Context context, int resource) {
            super(context, resource);
            inflater = LayoutInflater.from(context);
            res = resource;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if(convertView == null) convertView = inflater.inflate(res, null);
            TextView textView = convertView.findViewById(android.R.id.text1);
            textView.setText(getItem(position));
            return convertView;
        }

        @Nullable
        @Override
        public String getItem(int position) {
            return strs[position];
        }

        @Override
        public int getCount() {
            return strs.length;
        }
    }

    /**
     * click the three icon
     * */
    @Override
    public void onClick(View view) {

        Log.e("zxy","the tag_pos is::" + tag_pos);
        String input = et_input.getText().toString().trim();
        int clickImg = view.getId();
        if(clickImg == R.id.im_metre && tag_pos == 0){
            lengthFragment = new LengthFragment(this, input);
            switchFragment(lengthFragment);
        }else if(clickImg == R.id.im_celsius && tag_pos == 1){
            tempFragment = new TempFragment(this, input);
            switchFragment(tempFragment);
        }else if(clickImg == R.id.im_kilograms && tag_pos == 2){
            weightFragment = new WeightFragment(this, input);
            switchFragment(weightFragment);
        }else{
            Toast.makeText(this, "Please select the correct conversion icon", Toast.LENGTH_SHORT).show();
        }
    }

    private void switchFragment(Fragment targetFragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if(!targetFragment.isAdded()){
            transaction
                    .hide(currentFragment)
                    .add(R.id.frame_page, targetFragment, targetFragment.getClass().getName())
                    .commit();
        }else{
            transaction
                    .hide(currentFragment)
                    .show(targetFragment)
                    .commit();
        }
        currentFragment = targetFragment;
    }
}