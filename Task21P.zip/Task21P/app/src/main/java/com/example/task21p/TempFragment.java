package com.example.task21p;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.DecimalFormat;


@SuppressLint("ValidFragment")
public class TempFragment extends Fragment {
    Context mContext;
    String mInput;
    RelativeLayout rl_temp;
    TextView tv_fah;
    TextView tv_kelvin;

    @SuppressLint("ValidFragment")
    public TempFragment(Context context, String input){
        this.mContext = context;
        this.mInput = input;
    }
    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @deprecated
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frame_temp, container, false);
        rl_temp = view.findViewById(R.id.rl_temp);
        tv_fah = view.findViewById(R.id.tv_fah);
        tv_kelvin = view.findViewById(R.id.tv_kelvin);
        if(mInput != null && !mInput.equals("")){
            rl_temp.setVisibility(View.VISIBLE);
            int m = Integer.parseInt(mInput);
            DecimalFormat df = new DecimalFormat("#,###,##0.00");
            tv_fah.setText(df.format(m*1.8+32));
            tv_kelvin.setText(df.format(m+273.15));
        }
        return view;
    }
}
