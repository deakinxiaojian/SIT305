package com.example.task21p;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.DecimalFormat;

@SuppressLint("ValidFragment")
public class WeightFragment extends Fragment {
    Context mContext;
    String mInput;
    RelativeLayout rl_weight;
    TextView tv_gram;
    TextView tv_oz;
    TextView tv_lb;

    @SuppressLint("ValidFragment")
    public WeightFragment(Context context, String input){
        this.mContext = context;
        this.mInput = input;
    }
    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @deprecated
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frame_weight, container, false);
        rl_weight = view.findViewById(R.id.rl_weight);
        tv_gram = view.findViewById(R.id.tv_gram);
        tv_oz = view.findViewById(R.id.tv_oz);
        tv_lb = view.findViewById(R.id.tv_lb);
        if(mInput != null && !mInput.equals("")){
            rl_weight.setVisibility(View.VISIBLE);
            int m = Integer.parseInt(mInput);
            DecimalFormat df = new DecimalFormat("#,###,##0.00");
            tv_gram.setText(Integer.toString(m*1000));
            tv_oz.setText(df.format(m*35.27396194958));
            tv_lb.setText(df.format(m*2.20462262));
        }
        return view;
    }
}
