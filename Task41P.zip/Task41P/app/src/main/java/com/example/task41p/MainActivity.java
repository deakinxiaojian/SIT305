package com.example.task41p;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private int seconds = 0;
    private int minute = 0;
//    private int hour = 0;
    private boolean running = false;
    private boolean wasRunning = false;
    private Handler handler;
    private String taskName;

    private SharedPreferences sp_last_timer;
    private SharedPreferences.Editor sp_editor;

    private TextView tv_last_timer;
    private TextView tv_last_taskname;
    private TextView tv_timer;
    private ImageView im_start;
    private ImageView im_pause;
    private ImageView im_stop;
    private EditText et_task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_last_timer = findViewById(R.id.tv_2);
        tv_last_taskname = findViewById(R.id.tv_4);
        tv_timer = findViewById(R.id.tv_timer);
        im_start = findViewById(R.id.im_start);
        im_pause = findViewById(R.id.im_pause);
        im_stop = findViewById(R.id.im_stop);
        et_task = findViewById(R.id.et_task);
        im_start.setOnClickListener(this);
        im_pause.setOnClickListener(this);
        im_stop.setOnClickListener(this);
        et_task.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                taskName = editable.toString();
                Log.e("zxy","the taskName is::" + taskName);
            }
        });



        if(savedInstanceState != null){
            Log.e("zxy", "savedInstanceState is not null" + seconds);
            seconds = savedInstanceState.getInt("seconds");
            running = savedInstanceState.getBoolean("running");
            wasRunning = savedInstanceState.getBoolean("wasRunning");
        }

        sp_last_timer = this.getSharedPreferences("sp_last_timer", MODE_PRIVATE);
        sp_editor = sp_last_timer.edit();
        setlastTimerDesc();

        handler = new Handler();
        runTimer();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("seconds", seconds);
        outState.putBoolean("running", running);
        outState.putBoolean("wasRunning", wasRunning);
    }

    private void runTimer(){
        handler.post(new Runnable() {
            @Override
            public void run() {
                if(running) {
                    ++seconds;
                }
//                hour = seconds/3600;
                minute = seconds%3600/60;
                String time = String.format("%02d:%02d", minute, seconds%60);
                tv_timer.setText(time);
                handler.postDelayed(this, 1000);
            }
        });


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.im_start:
                running = true;
                break;
            case R.id.im_pause:
                running = false;
                break;
            case R.id.im_stop:
                running = false;
                sp_editor.putInt("seconds", seconds);
                sp_editor.putString("taskName", taskName);
                sp_editor.apply();
                seconds = 0;
                setlastTimerDesc();
                break;
        }
    }

    //set the spent description
    public void setlastTimerDesc(){
        if(sp_last_timer != null){
            int last_seconds = sp_last_timer.getInt("seconds", 0);
            String last_taskname = sp_last_timer.getString("taskName", "...");
//            hour = last_seconds/3600;
            minute = last_seconds%3600/60;
            tv_last_timer.setText(String.format("%02d:%02d", minute, last_seconds%60));
            tv_last_taskname.setText(last_taskname);
        }

    }
}